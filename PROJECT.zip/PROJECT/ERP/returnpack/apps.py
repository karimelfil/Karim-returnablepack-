from django.apps import AppConfig


class ReturnpackConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'returnpack'
